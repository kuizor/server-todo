class Carpa
	attr_reader :capacidad
	def initialize
		@capacidad = Array.new
	end

	def agregar_publico(publico)
		@publico = publico
		if(valida_capacidad_max==0)
			puts "Capacidad excedida"
		else
			@capacidad.push(publico)
		end
	end
	def valida_capacidad_max
		if(@publico > 1000)
			return 0
		end 
	end
end