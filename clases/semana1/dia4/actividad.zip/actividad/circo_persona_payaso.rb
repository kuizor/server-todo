class Payaso
	attr_accessor :nombre, :apellido
	def initialize (nombre, apellido)
		@nombre = nombre
		@apellido = apellido
	end
	
end