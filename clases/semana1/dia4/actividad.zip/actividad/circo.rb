require_relative "circo_animales"
require_relative "circo_carpa"
require_relative "circo_persona"
require_relative "circo_persona_payaso"

class Circo
	def initialize
		@animal = Array.new
		@person = Array.new
	end

	def cantidad_payasos
		@persona.select{|i| i.persona}.count
	end

	def cantidad_animales
		@animales.select{|i| i.animales}.count
	end

end