class Animales
	attr_accessor :nombre, :especie
	
	def initialize (nombre, especie)
		@nombre = nombre
		@especie = especie
	end
end