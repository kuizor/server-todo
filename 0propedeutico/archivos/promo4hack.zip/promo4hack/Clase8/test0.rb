for i in 0..-1
	puts "*"
end