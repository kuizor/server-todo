# Realice el algoritmo para resolver las disyuntivas de la vida

if rand(2) == 0
	puts "Me voy por la opcion 1"
else
	puts "Me voy por la opcion 2"
end

