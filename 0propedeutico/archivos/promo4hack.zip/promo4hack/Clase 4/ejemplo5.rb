
puts "Cantidad de opciones: "
op = gets.chomp.to_i
opt = rand(op)
puts "Me voy por la decisión #{opt+1}" + op.to_s

puts "Hola" + " " + "Rosa"

p = "Letty"
q = "Rosa"

puts "Hola " + p + " y " + q


