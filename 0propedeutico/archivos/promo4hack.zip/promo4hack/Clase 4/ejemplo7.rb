# Algoritmo para encontrar el área de una círculo, dado su diámetro


