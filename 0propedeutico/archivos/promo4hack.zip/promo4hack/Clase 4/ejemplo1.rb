puts("Ingrese su edad:")

var1 = gets.chomp

puts var1
puts var1.class

var1 = var1.to_i
puts var1.class

puts("Hola mundo")
