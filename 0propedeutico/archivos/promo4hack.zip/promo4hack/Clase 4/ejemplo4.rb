# Realice el algoritmo para tomar decisiones de la vida

op = rand(5)

if op == 0
	puts "Me voy por la opcion 1"
elsif op == 1 
	puts "Me voy por la opcion 2"
elsif op == 2
	puts "Me voy por la opcion 3"
elsif op == 3 
	puts "Me voy por la opcion 4"
else
	puts "Me voy por la opcion 5"
end
