# Indague que hace el siguiente codigo fuente

a = []

for i in 0..9
	a[i] = rand(100) + 1
end

puts "Arreglo: #{a}"