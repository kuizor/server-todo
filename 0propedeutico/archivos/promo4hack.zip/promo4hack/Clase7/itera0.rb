
for i in 0..0 do
	puts "*"
end